<html>

<?php
// connect db
$mysqli= new mysqli ("localhost", "root", "", "database1")
           or die ("Connection fail". $mysqli->connect_error);
		   

if (isset($_POST['submit'])) {
	
$fname=trim($_POST["fname"]);
$lname=trim($_POST["lname"]);
$email=trim($_POST["email"]);
$mobile=trim($_POST["mobile"]);
$gender=$_POST["gender"];
$birthday=$_POST["bdaymonth"];
$address=trim($_POST["address"]);
$course=$_POST["course"];

//check if account existed
$sql= "select * from customer where mobileNum= $mobile";
$result= $mysqli->query($sql);


if ((mysqli_num_rows ( $result ) ==1)) {
	  
	 echo 
		"<script type='text/javascript'>".
		"alert('Account Existed!')".
		"</script>";
	 echo "<meta http-equiv='refresh' content='0'>";
}else {
	
	$sql="insert into customer (fname, lname, email, mobileNum, gender, birthday, address, course) values (
          '$fname',
	      '$lname',
		  '$email',
		  '$mobile',
		  '$gender',
		  '$birthday',
		  '$address',
		  '$course');";
		  
		  $result= $mysqli->query($sql);
		 echo 
		"<script type='text/javascript'>".
		"alert('Thank for your submission. We will contact you very soon.')".
		"</script>";
		echo "<meta http-equiv='refresh' content='0'>";
}

}else
echo
<<<HTML
<head>

   
   <meta charset="utf-8" />
   <meta name="viewport" content="width=device-width, initial-scale=1" />
   <title>Join our Courses</title>
   <link href="reset.css" rel="stylesheet" />
   <link href="styles.css" rel="stylesheet" />  
   <link href="tables.css" rel="stylesheet" /> 
   <link href="Validation.css" rel="stylesheet" /> 
 <script src="formsubmit2.js"></script>
</head>

<body>
   <header>
       <div id="slider">
	      <figure>
	      <img src="images/html.jpg" alt="HTML5" class="logoimg" />
		  <img src="images/css.png" alt="CSS3" class="logoimg" />
		  <img src="images/javascript.png" alt="JavaScript" class="logoimg" />
		  <img src="images/jquery.png" alt="jQuery" class="logoimg" />
		  <img src="images/bootstrap.png" alt="Bootstrap" class="logoimg" />
          <figure>
	  </div>     
	  <nav class="tabs"> <a id="navicon" href="#">
         <ul>
            <li><a href="205CDE.html">Home</a></li>
            <li><a href="HTML.html">HTML</a></li>
            <li><a href="CSS.html">CSS</a></li>
            <li><a href="javascript.html">JavaScript</a></li>
            <li><a href="jquery.html">jQuery</a></li>
			<li><a href="bootstrap.html">Bootstrap</a></li>
            <li><a class="current" href="#">Our Courses</a></li>
		    
         </ul>
      </nav>
   </header>
   
 <section>
 <article>
       <h1>Come Join Our Courses</h1>
      <p>After having brief understanding of these web developing languages, you may
	     want to learn more about these languages. Here is your chance, we can provide 
		 tutorial courses for you. After attending our courses, we can ensure that you 
		 will be able to create an appealing website packed with functionalities. Our 
		 courses will not only cover those basics included in the introduction videos, 
		 but also professional techniques about those languages. 
	  </p>
	  <p>If you are interested, please leave your personal details down below and don't 
	     forget to pick the course you want to attend. We will contact you through
		 email and provide you with course details. Thank you!
      </p>		 
 </article>
	
 
	<div class="formTbl">
	<form method="post" action="{$_SERVER['PHP_SELF']}">		
	<fieldset>
	<legend>Personal Information:</legend>
		<input id="namebox" type="text" name="fname" placeholder="First name" required/> <br>  
		<input id="namebox" type="text" name="lname" placeholder="Last name" required/> <br>  
		<input id="namebox" type="email" name="email" placeholder="Email" required/> <br> 
		<input type="tel" name="mobile" placeholder="Mobile"> <br>		
		
		<input type="radio" name="gender" value="male" checked> Male  
		<input type="radio" name="gender" value="female"> Female <br> <br>
		
		Birthday (month and year): <br>
		<input type="month" name="bdaymonth">  <br> <br>
		
		Address:<br>
		<textarea placeholder="Comment" name="address" rows="10" cols="30" > 
		</textarea> <br> <br>
		
		Choose Course:<br>
		<input type="radio" name="course" value="HTML Basics" checked>HTML Basics
		<input type="radio" name="course" value="CSS Basics">CSS Basics
		<input type="radio" name="course" value="JavaScript Basics">JavaScript Basics</br>
		<input type="radio" name="course" value="jQuery Basics">jQuery Basics
		<input type="radio" name="course" value="Bootstrap Basics">Bootstrap Basics
		
		<br>
		<input type="submit" name="submit" value="Submit">
		<input type="reset" value="Reset"></br>
		
	</fieldset>
	</form>
	</div> 
	 
	</section>
      
   <footer>
      <nav>
           
      </nav>
      <section>
         Contact Us <br />
         Tel: (852) 1234 - 5678<br />
         Email: webdeveloping@gmail.com <br />
      </section>   
	   

	   
	   
   </footer>
      
</body>

HTML;
?>

</html>